# Plugabyte ghost — cursor-following 3D mascot

A self-contained copy of the ghost from the Plugabyte homepage: a lathe-built
solid of revolution in three.js, lit by a baked studio environment, that turns
its head toward the pointer and waves when left alone.

## Just look at it

Open `index.html`. Everything is bundled into `ghost.js` — no server, no build,
no network. Move the pointer; the head follows. It waves after 15s idle, or on
the button.

## Use it in a React app

Copy `src/ghostGeometry.ts` and `src/GhostScene.tsx` into your project.

```bash
npm install three @react-three/fiber react react-dom
```

```tsx
import { useRef } from 'react';
import GhostScene, { type GhostHandle } from './GhostScene';

const ghost = useRef<GhostHandle>(null);

// The scene fills its parent, so the parent is what sets the size.
<div style={{ width: 420, height: 420 }} onPointerMove={e => {
  const r = e.currentTarget.getBoundingClientRect();
  ghost.current?.setLookAt(
    ((e.clientX - r.left) / r.width) * 2 - 1,
    -(((e.clientY - r.top) / r.height) * 2 - 1),
  );
}}>
  <GhostScene ref={ghost} />
</div>
```

### Handle

| Method | Does |
| --- | --- |
| `setLookAt(x, y)` | Head turn. Both axes are −1…1 and are clamped; `(0, 0)` faces front. |
| `playWave()` | One wave, ~1.4s, then back to idle. |
| `playThinking(on)` | Spins the bolt until switched off. |

### Props

| Prop | Default | |
| --- | --- | --- |
| `ghostColor` | `#8FB8E8` | Body. Brand Sky. |
| `boltColor` | `#F4586A` | Bolt. Brand Bolt Red. |
| `onReady` | — | Fires once the first frame is on screen. |
| `pose` | — | Freezes the rig in a held pose for still renders. **While set, the idle loop and `setLookAt` do nothing** — leave it off for the interactive ghost. |

## Files

```
index.html            demo page
ghost.js              bundle (React + three + the ghost, ~1 MB minified)
src/GhostScene.tsx    the rig: geometry, materials, lighting, animation
src/ghostGeometry.ts  the silhouette — lathe profile, hem wave, surfaceAt()
src/demo.tsx          pointer tracking and idle wave for the demo page
nextjs-original/      the site's own wrappers, for reference only
```

`nextjs-original/` needs Next.js and CSS modules, so it will not build outside
that app. It is included because it holds two things the bare scene does not:
`Ghost.tsx` defers the WebGL mount and falls back to a flat SVG sprite if WebGL
never arrives, and `LandingSection.excerpt.tsx` is where the real pointer
handling and idle timer live on the site.

## Notes

- Pointer events, not mouse events, so it tracks a finger on a phone too. Give
  the tracking element `touch-action: none` or the browser will scroll instead.
- Cache the `getBoundingClientRect()` per gesture rather than reading it on
  every move — otherwise it is a layout read per event.
- The environment map is generated at runtime from three's `RoomEnvironment`,
  so there is no HDRI to ship and nothing is fetched.
