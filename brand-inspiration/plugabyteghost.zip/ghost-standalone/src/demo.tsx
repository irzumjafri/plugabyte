/**
 * Standalone cursor-following ghost.
 *
 * The pointer handling here is lifted from the site's LandingSection: pointer
 * events rather than mouse events, so it reacts on a phone too, and the
 * bounding rect is cached because reading it on every move is a layout read per
 * event. The idle wave fires when nobody has moved for a while.
 */
import { StrictMode, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import GhostScene, { type GhostHandle } from './GhostScene';

const IDLE_WAVE_MS = 15000;

function Demo() {
  const ghost = useRef<GhostHandle>(null);
  const rect = useRef<DOMRect | null>(null);
  const idle = useRef<ReturnType<typeof setTimeout> | null>(null);

  // The site's version re-armed this inside its own callback with no cleanup,
  // so the wave loop outlived the component. Clear it on unmount.
  useEffect(() => () => { if (idle.current) clearTimeout(idle.current); }, []);

  function resetIdle() {
    if (idle.current) clearTimeout(idle.current);
    idle.current = setTimeout(() => { ghost.current?.playWave(); resetIdle(); }, IDLE_WAVE_MS);
  }

  function onPointerMove(e: React.PointerEvent<HTMLDivElement>) {
    const r = rect.current ?? e.currentTarget.getBoundingClientRect();
    rect.current = r;
    const nx = ((e.clientX - r.left) / r.width) * 2 - 1;
    const ny = ((e.clientY - r.top) / r.height) * 2 - 1;
    ghost.current?.setLookAt(nx, -ny);
    resetIdle();
  }

  return (
    <div
      className="stage"
      onPointerMove={onPointerMove}
      onPointerEnter={e => { rect.current = e.currentTarget.getBoundingClientRect(); resetIdle(); }}
      onPointerLeave={() => ghost.current?.setLookAt(0, 0)}
    >
      <div className="ghost">
        <GhostScene ref={ghost} />
      </div>
      <p className="hint">move your cursor — click to wave</p>
      <button className="wave" onClick={() => ghost.current?.playWave()}>wave</button>
    </div>
  );
}

createRoot(document.getElementById('root')!).render(<StrictMode><Demo /></StrictMode>);
